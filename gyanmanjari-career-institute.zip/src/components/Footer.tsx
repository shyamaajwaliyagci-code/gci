import { useState } from 'react';
import { ArrowUp } from 'lucide-react';

export default function Footer() {
  const [imgError, setImgError] = useState(false);

  return (
    <footer className="bg-gray-900 text-white py-12 border-t-4 border-secondary border-opacity-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center">
        <div className="mb-6 md:mb-0 text-center md:text-left flex flex-col items-center md:items-start">
          {!imgError ? (
            <img 
              src="/gci.png" 
              alt="Gyanmanjari Career Institute" 
              className="h-16 w-auto object-contain mb-3 bg-white/90 p-2 rounded-xl" 
              onError={() => setImgError(true)}
            />
          ) : (
            <div className="text-2xl font-serif font-bold text-white mb-2">
              Gyanmanjari <span className="text-secondary">Career Institute</span>
            </div>
          )}
          <p className="text-gray-400 text-sm font-medium">Where Success Is The Tradition</p>
        </div>
        
        <div className="flex flex-col items-center md:items-end">
          <a href="#" className="w-12 h-12 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-colors mb-6 text-gray-300 hover:text-white group">
            <ArrowUp className="w-6 h-6 transform group-hover:-translate-y-1 transition-transform" />
          </a>
          <p className="text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} GCI. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
