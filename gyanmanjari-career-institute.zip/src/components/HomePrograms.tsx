import { motion } from 'motion/react';
import { Palette, Music, Puzzle, Shapes, Heart, Sprout, Smile, BookOpen, GraduationCap } from 'lucide-react';

const programs = [
  {
    name: "Playgroup",
    age: "2 - 3 Years",
    desc: "A warm, nurturing environment where toddlers explore their senses, build social skills, and learn through guided play and discovery.",
    skills: ["Sensory Exploration", "Socializing", "Basic Motor Skills"],
    icon: Smile,
    color: "text-rose-500",
    bg: "bg-rose-50",
    border: "border-rose-100"
  },
  {
    name: "Nursery",
    age: "3 - 4 Years",
    desc: "Fostering curiosity and independence through interactive storytelling, creative arts, and foundational learning activities.",
    skills: ["Language Development", "Creativity", "Early Problem Solving"],
    icon: Palette,
    color: "text-amber-500",
    bg: "bg-amber-50",
    border: "border-amber-100"
  },
  {
    name: "Junior KG",
    age: "4 - 5 Years",
    desc: "Building a strong academic foundation with a focus on phonics, numbers, and understanding the world around them.",
    skills: ["Pre-Reading Skills", "Basic Math", "Teamwork"],
    icon: Puzzle,
    color: "text-emerald-500",
    bg: "bg-emerald-50",
    border: "border-emerald-100"
  },
  {
    name: "Senior KG",
    age: "5 - 6 Years",
    desc: "Preparing for primary school with structured learning, advanced reading and writing, and critical thinking development.",
    skills: ["Reading & Writing", "Logical Thinking", "School Readiness"],
    icon: Shapes,
    color: "text-sky-500",
    bg: "bg-sky-50",
    border: "border-sky-100"
  },
  {
    name: "Primary",
    age: "Grades 1 - 4",
    desc: "A comprehensive foundational phase where students build strong academic concepts, critical reasoning, and effective communication skills.",
    skills: ["Conceptual Clarity", "Communication", "Analytical Skills"],
    icon: Puzzle, // Using an existing imported icon, or we can use others
    color: "text-indigo-500",
    bg: "bg-indigo-50",
    border: "border-indigo-100"
  },
  {
    name: "Upper Primary",
    age: "Grades 5 - 7",
    desc: "Encouraging independent learning, practical application of knowledge, and a deeper understanding of diverse subjects.",
    skills: ["Independent Learning", "Subject Mastery", "Life Skills"],
    icon: BookOpen,
    color: "text-purple-500",
    bg: "bg-purple-50",
    border: "border-purple-100"
  }
];

export default function HomePrograms() {
  return (
    <section className="py-24 bg-gray-50 border-b border-gray-100 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-10 left-10 text-rose-200/50 hidden md:block">
        <Heart className="w-24 h-24 transform -rotate-12" />
      </div>
      <div className="absolute bottom-10 right-10 text-emerald-200/50 hidden md:block">
        <Sprout className="w-32 h-32 transform rotate-12" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-primary mb-6">Our Foundational Programs</h2>
            <p className="text-gray-600 text-lg leading-relaxed">
              We offer age-appropriate, carefully crafted programs that ensure every child reaches their developmental milestones with joy and confidence.
            </p>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {programs.map((prog, i) => (
            <motion.div
              key={prog.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`bg-white rounded-3xl p-8 border ${prog.border} shadow-lg shadow-gray-200/40 relative group hover:-translate-y-2 transition-transform duration-300`}
            >
              <div className="absolute -top-6 -right-6 w-24 h-24 bg-white/50 blur-2xl rounded-full group-hover:bg-opacity-80 transition-all"></div>
              <div className={`w-16 h-16 ${prog.bg} ${prog.color} rounded-2xl flex items-center justify-center mb-6`}>
                <prog.icon className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-serif font-bold text-gray-900 mb-1">{prog.name}</h3>
              <p className={`font-bold ${prog.color} text-sm mb-4 bg-white/50 inline-block px-3 py-1 rounded-full border ${prog.border}`}>{prog.age}</p>
              <p className="text-gray-600 text-sm leading-relaxed mb-6">
                {prog.desc}
              </p>
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Key Focus</h4>
                <ul className="space-y-2">
                  {prog.skills.map((skill, j) => (
                    <li key={j} className="flex items-center text-sm font-medium text-gray-700">
                      <span className={`${prog.color} mr-2`}>●</span> {skill}
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}