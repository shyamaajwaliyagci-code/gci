import { motion } from 'motion/react';
import { BookOpen, Users, Star } from 'lucide-react';

export default function HomeDetails() {
  const highlights = [
    {
      icon: BookOpen,
      title: "Playful Learning",
      description: "We use interactive, experience-based methods to make every lesson an exciting discovery.",
      color: "text-blue-500",
      bg: "bg-blue-50",
    },
    {
      icon: Users,
      title: "Caring Environment",
      description: "Our dedicated educators ensure every child feels safe, valued, and encouraged to grow.",
      color: "text-green-500",
      bg: "bg-green-50",
    },
    {
      icon: Star,
      title: "Excellence",
      description: "We build strong foundations in academics side-by-side with character and creativity.",
      color: "text-yellow-500",
      bg: "bg-yellow-50",
    }
  ];

  return (
    <section className="py-20 bg-white border-b-8 border-secondary border-dashed">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-primary mb-4">Welcome to GCI Pre-Primary</h2>
          <p className="text-gray-600 text-lg">
            Gyanmanjari Career Institute provides a nurturing and joyful environment where your child's first educational steps are filled with wonder, play, and foundational learning.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {highlights.map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="text-center p-8 rounded-[2rem] border border-gray-100 shadow-xl shadow-gray-200/20 hover:-translate-y-2 transition-transform duration-300 bg-white"
            >
              <div className={`w-20 h-20 ${item.bg} ${item.color} rounded-2xl flex items-center justify-center mx-auto mb-6 transform rotate-3`}>
                <item.icon className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-serif font-bold text-gray-900 mb-3">{item.title}</h3>
              <p className="text-gray-600 font-medium">
                {item.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
