import { motion } from 'motion/react';
import { UserCircle, Network, BookOpenCheck, Cloud } from 'lucide-react';

export default function Leadership() {
  return (
    <section id="leadership" className="py-24 bg-sky-50/50 border-t-8 border-sky-100 border-dotted relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none z-0">
        <motion.div animate={{ x: [0, 40, 0] }} transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }} className="absolute top-20 right-10 text-white"><Cloud size={200} fill="currentColor" /></motion.div>
        <motion.div animate={{ x: [0, -30, 0] }} transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }} className="absolute bottom-10 left-10 text-white"><Cloud size={150} fill="currentColor" /></motion.div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2 className="text-sm text-secondary font-bold tracking-widest uppercase mb-2">Who We Are</h2>
          <h3 className="text-4xl md:text-5xl font-serif font-bold text-primary">Our Leadership Team</h3>
        </motion.div>

        <div className="grid lg:grid-cols-12 gap-12 items-start">
          
          {/* Founder */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-5 bg-white p-10 md:p-12 rounded-[2.5rem] shadow-xl border border-gray-100"
          >
            <div className="w-24 h-24 sm:w-32 sm:h-32 bg-orange-50 text-secondary rounded-[2rem] flex items-center justify-center mb-8 border border-orange-100 shadow-inner overflow-hidden">
              <img 
                src="/founder.png" 
                alt="Shree Avinash Patel"
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  e.currentTarget.parentElement?.classList.add('flex');
                  const icon = document.createElement('div');
                  icon.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user-circle"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="10" r="3"/><path d="M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662"/></svg>`;
                  icon.style.color = '#f97316'; // secondary color
                  e.currentTarget.parentElement?.appendChild(icon);
                }}
              />
            </div>
            <h4 className="text-3xl font-serif font-bold text-gray-900 mb-2">Shree Avinash Patel</h4>
            <p className="text-secondary font-bold uppercase tracking-widest text-xs mb-8">Founder</p>
            
            <div className="space-y-4 text-gray-600 leading-relaxed text-sm md:text-base font-medium">
              <p>
                The founder of GCI envisioned an educational organization that would redefine learning by placing children, teachers, and educational excellence at the heart of every initiative.
              </p>
              <p>
                With extensive experience in education, leadership, and organizational development, the founder has dedicated their career to creating opportunities that improve learning outcomes and empower educational communities. Their vision continues to guide the strategic direction and growth of GCI.
              </p>
            </div>
          </motion.div>

          {/* Core Team & Advisors */}
          <div className="lg:col-span-7 space-y-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-white p-10 rounded-[2.5rem] shadow-lg border border-gray-100 flex flex-col md:flex-row gap-8 items-start"
            >
              <div className="w-16 h-16 bg-blue-50 text-primary rounded-2xl flex items-center justify-center shrink-0 border border-blue-100">
                <Network className="w-8 h-8" />
              </div>
              <div>
                <h4 className="text-2xl font-serif font-bold text-gray-900 mb-3">Core Leadership Team</h4>
                <p className="text-gray-600 leading-relaxed mb-6 font-medium">Driving Excellence Through Experience and Vision. Ensuring quality and consistency across all GCI programs.</p>
                <div className="flex flex-wrap gap-2">
                  {["Strategic Initiatives", "Quality Assurance", "Teacher Training", "Innovation", "Sustainability"].map(badge => (
                    <span key={badge} className="px-3 py-1.5 bg-gray-50 border border-gray-200 text-gray-700 text-xs font-bold rounded-lg shadow-sm">
                      {badge}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="bg-white p-10 rounded-[2.5rem] shadow-lg border border-gray-100 flex flex-col md:flex-row gap-8 items-start"
            >
              <div className="w-16 h-16 bg-blue-50 text-primary rounded-2xl flex items-center justify-center shrink-0 border border-blue-100">
                <BookOpenCheck className="w-8 h-8" />
              </div>
              <div>
                <h4 className="text-2xl font-serif font-bold text-gray-900 mb-3">Academic Advisors & Experts</h4>
                <p className="text-gray-600 leading-relaxed mb-6 font-medium">Guiding Educational Innovation and Excellence. Supported by a network of experienced consultants, subject experts, and researchers.</p>
                <div className="flex flex-wrap gap-2">
                  {["Curriculum Design", "Research", "Academic Standards", "Best Practices"].map(badge => (
                    <span key={badge} className="px-3 py-1.5 bg-gray-50 border border-gray-200 text-gray-700 text-xs font-bold rounded-lg shadow-sm">
                      {badge}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
