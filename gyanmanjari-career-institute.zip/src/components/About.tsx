import { motion } from 'motion/react';
import { Target, Sprout, Star, Palette, Heart } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-24 bg-white relative overflow-hidden">
      {/* Playful Background Elements - Tailwind SVG Animations */}
      <div className="absolute inset-0 pointer-events-none z-0">
        {/* Star */}
        <svg className="absolute top-20 right-20 text-yellow-100 w-32 h-32 animate-spin-slow" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
        </svg>

        {/* Cloud */}
        <svg className="absolute bottom-20 left-10 text-orange-50 w-40 h-40 animate-float-delayed" viewBox="0 0 24 24" fill="currentColor">
          <path d="M17.5 19H6.5C3.46 19 1 16.54 1 13.5C1 10.6 3.23 8.2 6.07 8.04C6.88 5.16 9.54 3 12.5 3C16.03 3 18.9 5.82 19 9.35C21.32 9.5 23 11.45 23 13.75C23 16.65 20.65 19 17.5 19Z" />
        </svg>

        {/* Heart */}
        <svg className="absolute top-1/2 right-1/4 text-red-50 w-24 h-24 animate-pulse-slow" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 21.35L10.55 20.03C5.4 15.36 2 12.28 2 8.5C2 5.42 4.42 3 7.5 3C9.24 3 10.91 3.81 12 5.09C13.09 3.81 14.76 3 16.5 3C19.58 3 22 5.42 22 8.5C22 12.28 18.6 15.36 13.45 20.04L12 21.35Z" />
        </svg>
        
        {/* Circle */}
        <svg className="absolute top-10 left-1/3 text-blue-50 w-20 h-20 animate-float" viewBox="0 0 24 24" fill="currentColor">
          <circle cx="12" cy="12" r="10" />
        </svg>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16 md:mb-24"
        >
          <h2 className="text-sm text-secondary font-bold tracking-widest uppercase mb-2">About GCI</h2>
          <h3 className="text-4xl md:text-5xl font-serif font-bold text-primary">Our Journey & Purpose</h3>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <div className="inline-flex items-center justify-center p-4 bg-blue-50 rounded-2xl text-primary mb-2">
              <Target className="w-8 h-8" />
            </div>
            <h4 className="text-3xl font-serif font-bold text-gray-900">Why GCI was established</h4>
            <p className="text-gray-600 leading-relaxed text-lg">
              GCI was established with a clear purpose—to transform the educational experience of children by creating learning environments that nurture curiosity, creativity, confidence, and character. While academic excellence remains important, GCI believes that education must go beyond textbooks and examinations to prepare children for life.
            </p>
            <p className="text-gray-600 leading-relaxed text-lg">
              The founders recognized a growing need for educational institutions that combine strong academic foundations with holistic child development. Traditional approaches often focus heavily on academic achievement, leaving limited space for critical thinking, communication skills, emotional intelligence, creativity, and practical life skills. GCI was founded to bridge this gap.
            </p>
            
            <div className="pt-6">
              <h5 className="font-bold text-gray-900 mb-4 text-lg">Our enduring commitments:</h5>
              <ul className="space-y-4">
                {[
                  "Making quality education accessible and meaningful.",
                  "Creating child-centric learning experiences.",
                  "Empowering educators through continuous training and support.",
                  "Building strong partnerships between schools, teachers, parents, and communities.",
                  "Preparing learners to become responsible global citizens rooted in cultural values."
                ].map((item, i) => (
                  <li key={i} className="flex items-start">
                    <span className="h-6 w-6 rounded-full bg-secondary/10 flex items-center justify-center text-secondary mt-1 mr-4 shrink-0 font-bold text-sm">✓</span>
                    <span className="text-gray-700 font-medium">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-gray-50 p-8 md:p-10 rounded-[2.5rem] border border-gray-100 lg:sticky lg:top-32"
          >
            <div className="inline-flex items-center justify-center p-4 bg-orange-50 rounded-2xl text-secondary mb-6">
              <Sprout className="w-8 h-8" />
            </div>
            <h4 className="text-3xl font-serif font-bold text-gray-900 mb-8">A Story of Purpose, Progress, and Impact</h4>
            
            <div className="space-y-10 relative">
              <div className="absolute left-3.5 top-2 bottom-2 w-0.5 bg-gradient-to-b from-secondary via-primary/30 to-transparent"></div>
              
              <div className="relative pl-10">
                <div className="absolute left-2 top-1.5 w-3.5 h-3.5 bg-secondary rounded-full transform -translate-x-1/2 ring-4 ring-white"></div>
                <h5 className="font-bold text-primary text-xl mb-2">Early Foundation</h5>
                <p className="text-gray-600 leading-relaxed">Strengthening foundational learning and supporting schools with innovative educational practices. The initial focus was on creating effective learning frameworks and teacher development programs.</p>
              </div>
              
              <div className="relative pl-10">
                <div className="absolute left-2 top-1.5 w-3.5 h-3.5 bg-primary-light rounded-full transform -translate-x-1/2 ring-4 ring-white"></div>
                <h5 className="font-bold text-primary text-xl mb-3">Expansion of Educational Services</h5>
                <p className="text-gray-600 leading-relaxed mb-4">As schools began experiencing positive outcomes, GCI expanded its reach by developing:</p>
                <div className="flex flex-wrap gap-2 text-sm font-medium text-primary">
                  <span className="bg-white border border-gray-200/60 shadow-sm px-3 py-1.5 rounded-full">Structured curriculum</span>
                  <span className="bg-white border border-gray-200/60 shadow-sm px-3 py-1.5 rounded-full">Teacher training</span>
                  <span className="bg-white border border-gray-200/60 shadow-sm px-3 py-1.5 rounded-full">School leadership</span>
                  <span className="bg-white border border-gray-200/60 shadow-sm px-3 py-1.5 rounded-full">Parent engagement</span>
                  <span className="bg-white border border-gray-200/60 shadow-sm px-3 py-1.5 rounded-full">Student enrichment</span>
                </div>
              </div>

              <div className="relative pl-10">
                <div className="absolute left-2 top-1.5 w-3.5 h-3.5 bg-primary rounded-full transform -translate-x-1/2 ring-4 ring-white"></div>
                <h5 className="font-bold text-primary text-xl mb-2">Present Day</h5>
                <p className="text-gray-600 leading-relaxed">Through strategic partnerships and a commitment to excellence, GCI serves diverse educational communities while remaining true to our founding mission.</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
