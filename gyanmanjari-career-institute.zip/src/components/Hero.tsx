import { motion } from 'motion/react';
import { GraduationCap, ArrowRight, Star, Cloud, Music, Heart, Sun, Smile } from 'lucide-react';

export default function Hero({ setActiveTab }: { setActiveTab: (tab: string) => void }) {
  return (
    <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden bg-primary text-white">
      <div className="absolute inset-0 z-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-primary to-primary"></div>
      
      {/* Playful Floating SVG Objects for Kids - Tailwind Animations */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        {/* Star */}
        <svg className="absolute top-20 left-10 md:left-20 text-yellow-300 opacity-90 w-16 h-16 animate-float" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
        </svg>
        
        {/* Cloud */}
        <svg className="absolute top-32 right-10 md:right-32 text-sky-300 opacity-90 w-24 h-24 animate-float-delayed" viewBox="0 0 24 24" fill="currentColor">
          <path d="M17.5 19H6.5C3.46 19 1 16.54 1 13.5C1 10.6 3.23 8.2 6.07 8.04C6.88 5.16 9.54 3 12.5 3C16.03 3 18.9 5.82 19 9.35C21.32 9.5 23 11.45 23 13.75C23 16.65 20.65 19 17.5 19Z" />
        </svg>
        
        {/* Heart */}
        <svg className="absolute bottom-20 left-10 md:left-32 text-accent opacity-90 w-12 h-12 animate-pulse-slow" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 21.35L10.55 20.03C5.4 15.36 2 12.28 2 8.5C2 5.42 4.42 3 7.5 3C9.24 3 10.91 3.81 12 5.09C13.09 3.81 14.76 3 16.5 3C19.58 3 22 5.42 22 8.5C22 12.28 18.6 15.36 13.45 20.04L12 21.35Z" />
        </svg>

        {/* Circle */}
        <svg className="absolute bottom-32 right-10 md:right-20 text-green-300 opacity-90 w-16 h-16 animate-float" viewBox="0 0 24 24" fill="currentColor">
          <circle cx="12" cy="12" r="10" />
        </svg>

        {/* Triangle / Polygon */}
        <svg className="absolute top-1/2 left-2 md:left-1/4 text-secondary-light opacity-90 w-16 h-16 animate-spin-slow" viewBox="0 0 24 24" fill="currentColor">
          <polygon points="12,2 22,20 2,20" />
        </svg>

        {/* Sun shape */}
        <svg className="absolute top-1/4 right-5 md:right-1/4 text-yellow-400 opacity-90 w-20 h-20 animate-spin-slow" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2.25C12.4142 2.25 12.75 2.58579 12.75 3V5.25C12.75 5.66421 12.4142 6 12 6C11.5858 6 11.25 5.66421 11.25 5.25V3C11.25 2.58579 11.5858 2.25 12 2.25ZM12 18C12.4142 18 12.75 18.3358 12.75 18.75V21C12.75 21.4142 12.4142 21.75 12 21.75C11.5858 21.75 11.25 21.4142 11.25 21V18.75C11.25 18.3358 11.5858 18 12 18ZM3.75 12C3.75 11.5858 4.08579 11.25 4.5 11.25H6.75C7.16421 11.25 7.5 11.5858 7.5 12C7.5 12.4142 7.16421 12.75 6.75 12.75H4.5C4.08579 12.75 3.75 12.4142 3.75 12ZM18 12C18 11.5858 18.3358 11.25 18.75 11.25H21C21.4142 11.25 21.75 11.5858 21.75 12C21.75 12.4142 21.4142 12.75 21 12.75H18.75C18.3358 12.75 18 12.4142 18 12ZM18.364 5.63604C18.6569 5.34315 19.1317 5.34315 19.4246 5.63604C19.7175 5.92893 19.7175 6.40381 19.4246 6.6967L17.8337 8.28757C17.5408 8.58046 17.0659 8.58046 16.7731 8.28757C16.4802 7.99468 16.4802 7.5198 16.7731 7.22691L18.364 5.63604ZM4.57538 18.364C4.86827 18.0711 5.34315 18.0711 5.63604 18.364C5.92893 18.6569 5.92893 19.1317 5.63604 19.4246L4.04518 21.0155C3.75228 21.3084 3.27741 21.3084 2.98452 21.0155C2.69162 20.7226 2.69162 20.2477 2.98452 19.9548L4.57538 18.364ZM18.364 18.364C18.6569 18.6569 18.6569 19.1317 18.364 19.4246C18.0711 19.7175 17.5962 19.7175 17.3033 19.4246L15.7124 17.8338C15.4195 17.5409 15.4195 17.066 15.7124 16.7731C16.0053 16.4802 16.4802 16.4802 16.7731 16.7731L18.364 18.364ZM4.57538 5.63604C4.86827 5.92893 4.86827 6.40381 4.57538 6.6967C4.28249 6.98959 3.80761 6.98959 3.51472 6.6967L1.92386 5.10583C1.63096 4.81293 1.63096 4.33806 1.92386 4.04516C2.21675 3.75227 2.69163 3.75227 2.98452 4.04516L4.57538 5.63604ZM12 8.25C14.0711 8.25 15.75 9.92893 15.75 12C15.75 14.0711 14.0711 15.75 12 15.75C9.92893 15.75 8.25 14.0711 8.25 12C8.25 9.92893 9.92893 8.25 12 8.25Z" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex items-center justify-center space-x-2 text-secondary-light font-bold tracking-wider uppercase mb-6 text-sm bg-white/10 w-fit mx-auto px-6 py-2 rounded-full border border-white/20 shadow-sm"
          >
            <GraduationCap className="w-6 h-6" />
            <span>Transforming Learning</span>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-5xl md:text-7xl font-serif font-bold mb-6 leading-tight drop-shadow-lg"
          >
            Where Success Is The <span className="text-secondary drop-shadow-md">Tradition</span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-lg md:text-2xl text-gray-100 mb-10 max-w-3xl mx-auto leading-relaxed font-medium"
          >
            Creating joyful learning environments that nurture curiosity, creativity, confidence, and character. We prepare children for a wonderful life!
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-6"
          >
            <button onClick={() => setActiveTab('about')} className="bg-secondary hover:bg-secondary-light text-white text-lg px-8 py-4 rounded-full font-bold transition-all flex items-center shadow-lg hover:shadow-xl hover:-translate-y-1 w-full sm:w-auto justify-center border-4 border-white/20 cursor-pointer">
              Discover Our Journey
              <ArrowRight className="ml-2 w-6 h-6" />
            </button>
            <button onClick={() => setActiveTab('about')} className="bg-white hover:bg-gray-50 text-primary text-lg border-4 border-transparent px-8 py-4 rounded-full font-bold transition-all w-full sm:w-auto justify-center flex shadow-lg hover:shadow-xl hover:-translate-y-1 cursor-pointer">
              Our Mission
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
