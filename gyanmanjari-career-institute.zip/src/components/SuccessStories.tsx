import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Quote, Building, GraduationCap, Video, Users, FileText, X } from 'lucide-react';

const caseStudies = [
  {
    title: "Transforming a School Through Academic Excellence and System Development",
    content: "This case study highlights how a partner school collaborated with GCI to address challenges related to academic performance, instructional consistency, and school systems. Through a comprehensive audit, strategic planning process, teacher training initiatives, leadership coaching, and academic monitoring frameworks, the school achieved significant improvements in teaching quality and student outcomes.\n\nThe study explores the challenges faced, interventions implemented, measurable results achieved, and key lessons learned during the transformation journey. It demonstrates how systematic improvement efforts can create sustainable change and long-term success."
  },
  {
    title: "Building a Culture of Continuous Improvement: A School Transformation Journey",
    content: "This case study showcases the journey of a school that sought to strengthen leadership effectiveness, enhance teacher performance, and improve stakeholder engagement. GCI partnered with the institution to implement its School Transformation Framework, focusing on leadership development, capacity building, monitoring systems, and continuous improvement processes.\n\nThe narrative highlights the school's initial challenges, the transformation strategy adopted, implementation milestones, and the positive impact on students, teachers, and parents. It provides valuable insights into how strong leadership and collaborative practices can drive lasting educational excellence."
  }
];

export default function SuccessStories() {
  const [showCaseStudies, setShowCaseStudies] = useState(false);

  return (
    <div className="bg-gray-50 pt-20">
      <section className="py-20 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="text-4xl md:text-5xl font-serif font-bold text-primary mb-6">Success Stories</h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              At Gyanmanjari Career Institute (GCI), our greatest achievement is the success of the schools, leaders, teachers, students, and communities we serve.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-24">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="w-16 h-16 bg-orange-100 text-secondary-light rounded-2xl flex items-center justify-center mb-6">
                <Building className="w-8 h-8" />
              </div>
              <h2 className="text-3xl font-serif font-bold text-primary mb-4">Partner School Stories</h2>
              <p className="text-gray-600 text-lg mb-6 leading-relaxed">
                Every school has a unique story, and at GCI, we take pride in becoming a trusted partner in that journey. Our school partnerships are focused on identifying challenges, designing practical solutions, and implementing sustainable improvements.
              </p>
              <ul className="grid sm:grid-cols-2 gap-3 mb-8">
                {["Improved academic performance", "Enhanced curriculum implementation", "Stronger classroom practices", "Effective school management"].map((item, i) => (
                  <li key={i} className="flex items-center text-sm font-medium text-gray-700 bg-white px-4 py-2 rounded-lg shadow-sm border border-gray-100">
                    <span className="text-green-500 mr-2">✓</span> {item}
                  </li>
                ))}
              </ul>
              <div className="bg-primary text-white p-6 rounded-2xl shadow-lg border-l-4 border-secondary">
                <h4 className="font-bold mb-2">The Story of Balasinor</h4>
                <p className="text-sm text-primary-100">Representing a school that embraced change, invested in continuous improvement, and committed itself to providing the best learning experiences.</p>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-sky-50 rounded-[3rem] p-10 relative"
            >
              <img src="https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&q=80&w=1000" alt="Students in classroom" className="rounded-2xl shadow-2xl object-cover h-[400px] w-full" />
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl max-w-xs border border-gray-100">
                <div className="flex gap-2 text-yellow-400 mb-2">
                  {[...Array(5)].map((_, i) => <svg key={i} className="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" /></svg>)}
                </div>
                <p className="font-bold text-gray-900">Transforming challenges into opportunities</p>
              </div>
            </motion.div>
          </div>

          <div className="mb-20 text-center">
            <h2 className="text-3xl font-serif font-bold text-primary mb-12">Voices of Impact</h2>
            <div className="grid md:grid-cols-3 gap-8">
              
              <div className="bg-white p-8 rounded-3xl shadow-lg border border-gray-100 relative">
                <Quote className="absolute top-6 right-6 w-10 h-10 text-gray-100" />
                <GraduationCap className="w-10 h-10 text-blue-500 mb-4" />
                <h3 className="font-bold text-xl mb-4 text-gray-900">Principal Testimonial</h3>
                <p className="text-gray-600 mb-6 italic text-sm leading-relaxed">
                  "Working with GCI helped us establish clear academic systems and improve teaching quality across the school. The impact on both teachers and students has been remarkable."
                </p>
                <p className="font-bold text-sm text-gray-900">— School Principal, Mahuva</p>
              </div>

              <div className="bg-white p-8 rounded-3xl shadow-lg border border-gray-100 relative">
                <Quote className="absolute top-6 right-6 w-10 h-10 text-gray-100" />
                <Users className="w-10 h-10 text-green-500 mb-4" />
                <h3 className="font-bold text-xl mb-4 text-gray-900">Teacher Testimonial</h3>
                <p className="text-gray-600 mb-6 italic text-sm leading-relaxed">
                  "The training sessions completely changed the way I approach teaching. The strategies were practical, easy to implement, and highly effective."
                </p>
                <p className="font-bold text-sm text-gray-900">— Classroom Teacher, Modasa</p>
              </div>

              <div className="bg-white p-8 rounded-3xl shadow-lg border border-gray-100 relative">
                <Quote className="absolute top-6 right-6 w-10 h-10 text-gray-100" />
                <Users className="w-10 h-10 text-orange-500 mb-4" />
                <h3 className="font-bold text-xl mb-4 text-gray-900">Parent Testimonial</h3>
                <p className="text-gray-600 mb-6 italic text-sm leading-relaxed">
                  "We have seen tremendous growth in our child’s confidence, communication, and interest in learning. The positive changes made a noticeable difference."
                </p>
                <p className="font-bold text-sm text-gray-900">— Parent, Surat</p>
              </div>

            </div>
          </div>

          <div className="bg-primary rounded-[3rem] p-12 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-10">
              <FileText className="w-64 h-64 transform rotate-12" />
            </div>
            <div className="max-w-2xl relative z-10">
              <h2 className="text-3xl font-serif font-bold mb-4">Case Studies & Videos</h2>
              <p className="text-primary-100 text-lg mb-8 leading-relaxed">
                Our case studies showcase detailed examples of how GCI’s interventions lead to measurable improvements. With structured approaches to challenges, assessments, and implementations, we ensure sustainable growth.
              </p>
              <div className="flex flex-wrap gap-4">
                <button 
                  onClick={() => setShowCaseStudies(true)}
                  className="bg-white text-primary px-6 py-3 rounded-full font-bold shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer"
                >
                  Read Case Studies
                </button>
                <button className="bg-secondary text-white px-6 py-3 rounded-full font-bold shadow-lg flex items-center hover:bg-secondary-light transition-all cursor-pointer">
                  <Video className="w-5 h-5 mr-2" /> Watch Video Testimonials
                </button>
              </div>
            </div>
          </div>
          
        </div>
      </section>

      {/* Case Studies Modal */}
      <AnimatePresence>
        {showCaseStudies && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCaseStudies(false)}
              className="absolute inset-0 bg-primary/80 backdrop-blur-sm cursor-pointer"
            ></motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-y-auto relative z-10 shadow-2xl"
            >
              <div className="sticky top-0 bg-white/90 backdrop-blur-md px-8 py-6 border-b border-gray-100 flex justify-between items-center z-20">
                <h2 className="text-3xl font-serif font-bold text-primary">Case Studies</h2>
                <button 
                  onClick={() => setShowCaseStudies(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors cursor-pointer"
                >
                  <X className="w-6 h-6 text-gray-500" />
                </button>
              </div>
              
              <div className="p-8 space-y-12">
                <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100 mb-8">
                  <h3 className="font-bold text-blue-900 mb-3 uppercase tracking-wider text-sm">Typical Case Study Structure</h3>
                  <ul className="space-y-2 text-blue-800 text-sm">
                    <li><strong>The Challenge:</strong> Identifying academic, operational, or leadership-related concerns.</li>
                    <li><strong>The Assessment:</strong> Comprehensive audit, classroom observations, stakeholder interviews.</li>
                    <li><strong>The Solution:</strong> Customized action plan including training and curriculum enhancement.</li>
                    <li><strong>The Implementation:</strong> Collaborative execution of the transformation strategy.</li>
                    <li><strong>The Results:</strong> Improved performance, stronger practices, enhanced leadership.</li>
                  </ul>
                </div>

                {caseStudies.map((study, idx) => (
                  <div key={idx} className="border-b border-gray-100 pb-12 last:border-0 last:pb-0">
                    <div className="flex items-start gap-4 mb-4">
                      <div className="bg-secondary text-white w-10 h-10 rounded-full flex items-center justify-center font-bold shrink-0 mt-1">
                        {idx + 1}
                      </div>
                      <h3 className="text-2xl font-bold text-gray-900 font-serif leading-tight">{study.title}</h3>
                    </div>
                    <div className="pl-14 text-gray-600 leading-relaxed space-y-4">
                      {study.content.split('\n\n').map((paragraph, pIdx) => (
                        <p key={pIdx}>{paragraph}</p>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
