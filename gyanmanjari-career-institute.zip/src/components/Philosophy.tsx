import { motion } from 'motion/react';
import { Lightbulb, UserCheck, Compass, Heart, TrendingUp, Users, Smile, Star, Cloud } from 'lucide-react';

const philosophies = [
  {
    icon: UserCheck,
    title: "Child-Centered Learning",
    description: "Children learn best when actively engaged. We center learners, recognizing individual needs, interests, and developmental stages."
  },
  {
    icon: Compass,
    title: "Learning Through Experience",
    description: "Meaningful learning happens when children connect concepts to real life. We encourage hands-on, inquiry-based exploration."
  },
  {
    icon: Heart,
    title: "Holistic Development",
    description: "Education nurtures the whole child. Equal importance is given to social, emotional, physical, creative, and moral growth."
  },
  {
    icon: TrendingUp,
    title: "Growth Mindset",
    description: "We encourage learners to embrace challenges, learn from mistakes, and develop resilience as a journey of continuous improvement."
  },
  {
    icon: Users,
    title: "Collaborative Learning",
    description: "Learning flourishes through interaction. We promote teamwork, communication, respect, and shared learning experiences."
  },
  {
    icon: Lightbulb,
    title: "Continuous Improvement",
    description: "Education is constantly evolving. We remain committed to innovation, reflection, and improvement for best outcomes."
  }
];

export default function Philosophy() {
  return (
    <section id="philosophy" className="py-24 bg-white relative overflow-hidden">
      <div className="absolute inset-0 bg-sky-50/50 transform -skew-y-2 origin-top-left -z-10"></div>
      
      {/* Decorative stars and clouds */}
      <motion.div animate={{ scale: [1, 1.1, 1], rotate: [0, 20, 0] }} transition={{ duration: 8, repeat: Infinity }} className="absolute top-20 right-20 text-yellow-200 pointer-events-none -z-10"><Star size={120} fill="currentColor" /></motion.div>
      <motion.div animate={{ y: [0, -20, 0] }} transition={{ duration: 7, repeat: Infinity }} className="absolute bottom-40 left-10 text-orange-200 pointer-events-none -z-10"><Smile size={100} /></motion.div>
      <motion.div animate={{ x: [0, 20, 0] }} transition={{ duration: 10, repeat: Infinity }} className="absolute top-1/2 left-1/4 text-blue-100 pointer-events-none -z-10"><Cloud size={150} fill="currentColor" /></motion.div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16 md:mb-24"
        >
          <h2 className="text-sm text-secondary font-bold tracking-widest uppercase mb-2">Our Philosophy</h2>
          <h3 className="text-4xl md:text-5xl font-serif font-bold text-primary mb-6">Every Child Can Learn, Grow, and Succeed</h3>
          <p className="text-gray-600 text-lg leading-relaxed">
            At GCI, we believe that every child possesses unique strengths, talents, and learning potential. Education should not be limited to the transfer of knowledge; it should inspire exploration, encourage discovery, and cultivate a lifelong passion for learning.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {philosophies.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-3xl p-8 border border-gray-100 shadow-xl shadow-gray-200/20 hover:-translate-y-2 hover:shadow-2xl hover:border-primary/20 transition-all duration-300 group"
            >
              <div className="bg-blue-50 w-16 h-16 rounded-2xl flex items-center justify-center mb-8 border border-blue-100 group-hover:bg-primary group-hover:border-primary transition-colors duration-300">
                <item.icon className="w-8 h-8 text-primary group-hover:text-white transition-colors" />
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-4 font-serif">{item.title}</h4>
              <p className="text-gray-600 leading-relaxed font-medium">
                {item.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
