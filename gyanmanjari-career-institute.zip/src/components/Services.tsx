import { motion } from 'motion/react';
import { BookOpen, LineChart, Presentation, GraduationCap, Shapes, Smile, Settings, Users } from 'lucide-react';

const services = [
  {
    id: "curriculum",
    icon: BookOpen,
    title: "Curriculum Development",
    description: "A strong curriculum is the foundation of effective education. GCI develops structured, age-appropriate, competency-based curricula that align with educational standards.",
    details: [
      "Curriculum design and restructuring",
      "Academic planning and yearly scheduling of execution",
      "Assessment frameworks and evaluation systems",
      "Teaching-learning activity guidelines and worksheets",
      "Teacher training and subject expert interaction"
    ],
    outcomes: ["Clear academic progression", "Improved student learning outcomes", "Consistency in instruction", "Enhanced teacher confidence"]
  },
  {
    id: "management",
    icon: Settings,
    title: "School Management & Academic Excellence",
    description: "Effective schools require strong systems, clear processes, and a culture of continuous improvement. GCI supports schools in strengthening academic and operational excellence.",
    details: [
      "Academic followup and quality reviews",
      "Academic monitoring systems",
      "Standard Operating Procedures (SOPs)",
      "Performance tracking and reporting mechanisms",
      "Examination and assessment management"
    ],
    outcomes: ["Improved academic standards", "Streamlined school operations", "Data-driven decision-making", "Greater accountability"]
  },
  {
    id: "professional",
    icon: Presentation,
    title: "Teacher Professional Development",
    description: "Teachers are the most important factor in student success. GCI empowers educators through practical, classroom-focused professional development programs.",
    details: [
      "Effective teaching methodologies",
      "Classroom management strategies",
      "Activity-based learning techniques",
      "Student engagement strategies",
      "Technology integration in teaching"
    ],
    outcomes: ["Improved instructional quality", "Higher teacher confidence", "Better student engagement", "Consistent teaching standards"]
  },
  {
    id: "leadership",
    icon: GraduationCap,
    title: "Leadership Development",
    description: "Strong leadership creates strong schools. GCI develops educational leaders who can drive academic excellence, build positive school cultures, and lead sustainable change.",
    details: [
      "Instructional leadership",
      "Strategic planning",
      "School improvement management",
      "Team building and motivation",
      "Data-driven decision-making"
    ],
    outcomes: ["Stronger leadership capacity", "Enhanced school culture", "Improved team performance", "Sustainable institutional growth"]
  },
  {
    id: "enrichment",
    icon: Shapes,
    title: "Student Enrichment Programs",
    description: "Education extends beyond textbooks. GCI designs programs that nurture creativity, confidence, critical thinking, and life skills.",
    details: [
      "Communication and public speaking",
      "Leadership development",
      "Critical thinking and problem-solving",
      "Values and character education",
      "Social-emotional learning"
    ],
    outcomes: ["Holistic student development", "Increased confidence", "Enhanced future readiness", "Improved life skills"]
  },
  {
    id: "early-years",
    icon: Smile,
    title: "Early Years Excellence",
    description: "The early years form the foundation for lifelong learning. GCI specializes in creating high-quality preschool and kindergarten programs that foster joyful learning.",
    details: [
      "Preschool curriculum development",
      "Learning environment design",
      "Play-based learning implementation",
      "Early literacy and numeracy development",
      "Child observation and assessment systems"
    ],
    outcomes: ["Strong school readiness", "Improved foundational learning", "Enhanced child engagement", "Developmentally appropriate practices"]
  }
];

const frameworkSteps = [
  { step: 1, title: "Understand", sub: "School Audit & Needs Analysis", desc: "A comprehensive understanding of strengths, challenges, and growth opportunities." },
  { step: 2, title: "Design", sub: "Strategic Planning & Goal Setting", desc: "A clear and actionable transformation strategy aligned with school goals." },
  { step: 3, title: "Build", sub: "Curriculum Enhancement & Teacher Development", desc: "A strong foundation for effective implementation." },
  { step: 4, title: "Implement", sub: "Classroom Support & Leadership Coaching", desc: "Improved teaching practices and stronger leadership effectiveness." },
  { step: 5, title: "Monitor", sub: "Review Systems & Academic Tracking", desc: "Data-driven insights for informed decision-making." },
  { step: 6, title: "Improve", sub: "Continuous Feedback & Corrective Measures", desc: "Continuous improvement and sustained progress." },
  { step: 7, title: "Sustain", sub: "Long-Term Growth Planning", desc: "Long-term sustainability, organizational resilience, and ongoing academic excellence." }
];

export default function Services() {
  return (
    <div className="bg-gray-50 pt-20">
      {/* Intro */}
      <section className="py-20 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="text-4xl md:text-5xl font-serif font-bold text-primary mb-6">Our Services</h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              At Gyanmanjari Career Institute (GCI), we partner with schools to create sustainable systems that enhance teaching quality, strengthen leadership, improve student outcomes, and build future-ready learning environments.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12">
            {services.map((service, i) => (
              <motion.div 
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white rounded-[2rem] p-8 md:p-10 shadow-lg border border-gray-100"
              >
                <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-6">
                  <service.icon className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-serif font-bold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-8">{service.description}</p>
                
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-bold text-gray-900 mb-3 text-sm uppercase tracking-wider">Includes</h4>
                    <ul className="space-y-2">
                      {service.details.slice(0, 4).map((detail, j) => (
                        <li key={j} className="flex items-start text-sm text-gray-600">
                          <span className="text-secondary mr-2">•</span>
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-3 text-sm uppercase tracking-wider">Impact</h4>
                    <ul className="space-y-2">
                      {service.outcomes.map((outcome, j) => (
                        <li key={j} className="flex items-start text-sm text-gray-600">
                          <span className="text-green-500 mr-2">✓</span>
                          {outcome}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Framework Section */}
      <section className="py-24 bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-5xl font-serif font-bold mb-6">GCI School Transformation Framework</h2>
            <p className="text-primary-100 text-lg">A structured, research-based approach to achieving sustainable school improvement. The framework provides schools with a systematic pathway to achieve excellence.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {frameworkSteps.map((step, i) => (
              <motion.div 
                key={step.step}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white/10 rounded-3xl p-6 border border-white/20 relative overflow-hidden"
              >
                <div className="text-6xl font-bold text-white/5 absolute -top-2 -right-2">{step.step}</div>
                <div className="text-secondary-light font-bold mb-1 tracking-widest uppercase text-xs">Step {step.step}</div>
                <h3 className="text-xl font-serif font-bold mb-2">{step.title}</h3>
                <h4 className="text-sm font-semibold text-white/80 mb-3">{step.sub}</h4>
                <p className="text-white/70 text-sm leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="bg-secondary rounded-3xl p-6 border border-white/20 flex items-center justify-center text-center shadow-xl"
            >
              <div>
                <LineChart className="w-12 h-12 text-white/80 mx-auto mb-4" />
                <h3 className="text-xl font-serif font-bold mb-2">Why Choose GCI?</h3>
                <p className="text-white/90 text-sm">Proven expertise, customized solutions, experienced consultants, and sustainable systems.</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}
