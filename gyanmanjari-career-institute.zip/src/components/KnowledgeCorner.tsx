import { motion } from 'motion/react';
import { BookOpen, Lightbulb, Users, TrendingUp, Presentation } from 'lucide-react';

const blogs = [
  {
    category: "Educational Insights",
    title: "Why Foundational Learning Matters in Primary Education",
    desc: "The primary years are among the most important in a child's academic journey. Discover why building strong foundations in literacy, numeracy, and critical thinking is essential.",
    icon: BookOpen,
    color: "text-blue-600",
    bg: "bg-blue-50"
  },
  {
    category: "Educational Insights",
    title: "The Role of Holistic Development in Student Success",
    desc: "Education is much more than academic achievement. Holistic education nurtures intellectual, emotional, social, physical, and creative growth.",
    icon: TrendingUp,
    color: "text-green-600",
    bg: "bg-green-50"
  },
  {
    category: "Teaching Strategies",
    title: "Making Learning Active Through Classroom Engagement",
    desc: "Modern classrooms must move beyond passive learning. Learn how active learning places students at the center of the educational process.",
    icon: Lightbulb,
    color: "text-yellow-600",
    bg: "bg-yellow-50"
  },
  {
    category: "Teaching Strategies",
    title: "Using Assessment to Support Learning",
    desc: "Effective assessment serves a much broader purpose—it provides valuable information that guides teaching and supports student learning.",
    icon: Presentation,
    color: "text-purple-600",
    bg: "bg-purple-50"
  },
  {
    category: "Leadership Perspectives",
    title: "Building a Positive School Culture",
    desc: "A school's culture influences every aspect of teaching and learning. See how effective leadership is the driving force behind positive environments.",
    icon: Users,
    color: "text-orange-600",
    bg: "bg-orange-50"
  }
];

const articles = [
  {
    topic: "Curriculum",
    title: "Designing a Future-Ready Curriculum",
    desc: "In today's rapidly changing world, schools must move beyond traditional content delivery and focus on preparing students for future challenges with skills like critical thinking."
  },
  {
    topic: "Assessment",
    title: "Moving Beyond Marks and Grades",
    desc: "Modern educational practices recognize that assessment should be a powerful tool for improving learning. Shift from assessment of learning to assessment for learning."
  },
  {
    topic: "Early Childhood",
    title: "Creating Joyful Learning Environments",
    desc: "A child's first experiences with education should be positive, engaging, and meaningful. Joyful learning environments foster a love for learning that lasts a lifetime."
  }
];

export default function KnowledgeCorner() {
  return (
    <div className="bg-gray-50 pt-20">
      <section className="py-20 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="text-4xl md:text-5xl font-serif font-bold text-primary mb-6">Knowledge Corner</h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              Insights, strategies, and perspectives for educators, leaders, and parents aiming to transform education.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="mb-20">
            <h2 className="text-3xl font-serif font-bold text-primary mb-10 flex items-center">
              <span className="w-8 h-8 rounded-full bg-secondary text-white flex items-center justify-center mr-3 text-sm">1</span>
              Educational Blogs
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {blogs.map((blog, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-white rounded-3xl p-8 border border-gray-100 shadow-md hover:shadow-xl transition-shadow group"
                >
                  <div className={`w-14 h-14 ${blog.bg} ${blog.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                    <blog.icon className="w-7 h-7" />
                  </div>
                  <span className={`text-xs font-bold uppercase tracking-wider mb-3 block ${blog.color}`}>{blog.category}</span>
                  <h3 className="text-xl font-bold text-gray-900 mb-3 leading-tight font-serif">{blog.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed mb-6">{blog.desc}</p>
                  <button className="text-primary font-bold text-sm hover:text-secondary transition-colors items-center flex">
                    Read More <span className="ml-1">→</span>
                  </button>
                </motion.div>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-3xl font-serif font-bold text-primary mb-10 flex items-center">
              <span className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center mr-3 text-sm">2</span>
              In-Depth Articles
            </h2>
            <div className="space-y-6">
              {articles.map((article, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-white rounded-[2rem] p-8 border border-gray-100 shadow-sm hover:shadow-md transition-shadow flex flex-col md:flex-row gap-6 items-start md:items-center"
                >
                  <div className="md:w-1/4 shrink-0">
                    <span className="px-4 py-2 bg-gray-100 text-gray-700 font-bold text-xs uppercase tracking-wider rounded-lg">
                      {article.topic}
                    </span>
                  </div>
                  <div className="md:w-3/4">
                    <h3 className="text-2xl font-bold text-gray-900 mb-2 font-serif">{article.title}</h3>
                    <p className="text-gray-600 text-sm leading-relaxed">{article.desc}</p>
                  </div>
                  <div className="shrink-0 mt-4 md:mt-0">
                    <button className="bg-white border-2 border-primary text-primary hover:bg-primary hover:text-white px-6 py-2 rounded-full font-bold transition-all text-sm whitespace-nowrap">
                      Read Article
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

        </div>
      </section>
    </div>
  );
}
