import { motion } from 'motion/react';
import { Award, ShieldCheck, Handshake, Lightbulb, Users, HeartHandshake, BookOpen, CheckCircle, Star, Cloud, Music } from 'lucide-react';

const values = [
  { icon: Award, title: "Excellence", description: "Striving for the highest standards in teaching, learning, leadership, and service." },
  { icon: ShieldCheck, title: "Integrity", description: "Acting with honesty, transparency, accountability, and professionalism." },
  { icon: Handshake, title: "Respect", description: "Valuing the dignity, diversity, and unique contributions of every individual." },
  { icon: Lightbulb, title: "Innovation", description: "Embracing creativity and progressive educational practices that enhance outcomes." },
  { icon: Users, title: "Collaboration", description: "Building meaningful partnerships between educators, students, parents, and communities." },
  { icon: HeartHandshake, title: "Compassion", description: "Fostering caring, empathy, and emotional well-being to let every learner thrive." },
  { icon: BookOpen, title: "Lifelong Learning", description: "Promoting curiosity and continuous personal and professional growth." },
  { icon: CheckCircle, title: "Responsibility", description: "Encouraging individuals to take ownership and act as responsible global citizens." }
];

export default function CoreValues() {
  return (
    <section id="values" className="py-24 bg-primary text-white overflow-hidden relative border-y-[12px] border-secondary border-dashed">
      <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary-light/40 via-transparent to-transparent"></div>
      
      {/* Playful background elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <motion.div animate={{ x: [0, 20, 0] }} transition={{ duration: 8, repeat: Infinity }} className="absolute top-10 left-10 text-white/5"><Cloud size={160} fill="currentColor" /></motion.div>
        <motion.div animate={{ rotate: [0, 360] }} transition={{ duration: 20, repeat: Infinity, ease: "linear" }} className="absolute bottom-20 right-10 text-yellow-400/10"><Star size={200} fill="currentColor" /></motion.div>
        <motion.div animate={{ y: [0, -20, 0], rotate: [-10, 10, -10] }} transition={{ duration: 6, repeat: Infinity }} className="absolute top-1/2 left-1/4 text-green-300/10"><Music size={120} /></motion.div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-20"
        >
          <h2 className="text-sm text-secondary-light font-bold tracking-widest uppercase mb-2">Our Core Values</h2>
          <h3 className="text-4xl md:text-5xl font-serif font-bold mb-6">The Principles That Guide Us</h3>
          <p className="text-primary-100 text-lg leading-relaxed">
            Our values define our culture, shape our decisions, and inspire our work every day. They are the foundation of everything we build.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12">
          {values.map((value, index) => (
            <motion.div
              key={value.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              className="flex flex-col items-center text-center group"
            >
              <div className="w-20 h-20 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mb-6 group-hover:bg-secondary transition-colors duration-300 group-hover:border-secondary shadow-lg">
                <value.icon className="w-10 h-10 text-secondary-light group-hover:text-white transition-colors" />
              </div>
              <h4 className="text-xl font-bold mb-3 font-serif tracking-wide">{value.title}</h4>
              <p className="text-primary-100/80 leading-relaxed font-light text-sm">
                {value.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
