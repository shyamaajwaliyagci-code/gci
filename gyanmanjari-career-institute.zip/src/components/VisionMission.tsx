import { motion } from 'motion/react';
import { Eye, Rocket, Star, Sun } from 'lucide-react';

export default function VisionMission() {
  return (
    <section id="vision" className="py-24 bg-orange-50/50 border-y-8 border-secondary-light/30 border-dotted relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none z-0">
         <motion.div animate={{ rotate: 360 }} transition={{ duration: 30, repeat: Infinity, ease: "linear" }} className="absolute top-10 left-10 text-yellow-300 opacity-50"><Sun size={120} fill="currentColor" /></motion.div>
         <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 5, repeat: Infinity }} className="absolute bottom-10 right-20 text-orange-200 opacity-50"><Star size={100} fill="currentColor" /></motion.div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-8 md:gap-12">
          
          {/* Vision Card */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            whileInView={{ opacity: 1, scale: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-primary rounded-[3rem] p-10 md:p-14 text-white shadow-2xl relative overflow-hidden group border-4 border-primary-light/50"
          >
            <div className="absolute top-0 right-0 p-8 opacity-5 transition-opacity duration-500 group-hover:opacity-10">
              <Eye className="w-56 h-56 transform rotate-12 transition-transform duration-700 group-hover:scale-110" />
            </div>
            <div className="relative z-10">
              <div className="inline-flex items-center space-x-3 text-secondary-light font-bold uppercase tracking-widest mb-8 text-sm">
                <Eye className="w-6 h-6 border-2 border-secondary-light rounded-full p-1 border-opacity-50" />
                <span>Our Vision</span>
              </div>
              <h3 className="text-3xl md:text-4xl font-serif font-bold mb-8 leading-snug">
                To create a future where every child experiences meaningful, joyful, and high-quality education.
              </h3>
              <p className="text-primary-100 leading-relaxed text-lg opacity-90 font-light">
                We envision educational communities where students are empowered to become confident learners, compassionate individuals, critical thinkers, and responsible citizens capable of making positive contributions to society.
              </p>
            </div>
          </motion.div>

          {/* Mission Card */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            whileInView={{ opacity: 1, scale: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-[3rem] p-10 md:p-14 shadow-xl border border-gray-100/50 relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 p-8 opacity-[0.03] transition-opacity duration-500 group-hover:opacity-5">
              <Rocket className="w-56 h-56 transform -rotate-12 transition-transform duration-700 group-hover:scale-110 text-secondary" />
            </div>
            <div className="relative z-10">
              <div className="inline-flex items-center space-x-3 text-secondary font-bold uppercase tracking-widest mb-8 text-sm">
                <Rocket className="w-6 h-6 border-2 border-secondary rounded-full p-1 border-opacity-50" />
                <span>Our Mission</span>
              </div>
              <p className="text-gray-800 leading-relaxed mb-8 font-semibold text-xl font-serif">
                To provide transformative educational experiences by:
              </p>
              <ul className="space-y-5">
                {[
                  "Delivering high-quality, child-centered learning programs.",
                  "Supporting schools in achieving educational excellence.",
                  "Empowering teachers through continuous professional development.",
                  "Encouraging innovation in teaching and learning practices.",
                  "Fostering strong partnerships with parents and communities.",
                  "Promoting values-based education and character development."
                ].map((item, i) => (
                  <li key={i} className="flex items-start group/item">
                    <span className="h-2 w-2 rounded-full bg-secondary mt-2.5 mr-4 shrink-0 transition-transform group-hover/item:scale-150 group-hover/item:bg-accent"></span>
                    <span className="text-gray-600 font-medium block leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
