import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Menu, X, Home, Smile, Sparkles, Star, BookOpen, HeartHandshake } from 'lucide-react';

export default function Navbar({ activeTab, setActiveTab }: { activeTab: string, setActiveTab: (tab: string) => void }) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const tabs = [
    { id: 'home', name: 'Home', icon: Home, color: 'text-blue-500', bg: 'bg-blue-100', activeBg: 'bg-blue-500' },
    { id: 'about', name: 'About', icon: Smile, color: 'text-green-500', bg: 'bg-green-100', activeBg: 'bg-green-500' },
    { id: 'services', name: 'Services', icon: Sparkles, color: 'text-yellow-500', bg: 'bg-yellow-100', activeBg: 'bg-yellow-500' },
    { id: 'success', name: 'Stories', icon: Star, color: 'text-orange-500', bg: 'bg-orange-100', activeBg: 'bg-orange-500' },
    { id: 'knowledge', name: 'Knowledge', icon: BookOpen, color: 'text-purple-500', bg: 'bg-purple-100', activeBg: 'bg-purple-500' },
    { id: 'partner', name: 'Partner', icon: HeartHandshake, color: 'text-pink-500', bg: 'bg-pink-100', activeBg: 'bg-pink-500' },
  ];

  return (
    <header className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-white/90 backdrop-blur-md shadow-lg py-3' : 'bg-white/95 backdrop-blur-sm py-5'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <button onClick={() => setActiveTab('home')} className="flex flex-col text-left">
            {!imgError ? (
              <img 
                src="/gci.png" 
                alt="Gyanmanjari Career Institute" 
                className="h-14 md:h-[68px] w-auto object-contain drop-shadow-md transition-transform hover:scale-105" 
                onError={() => setImgError(true)}
              />
            ) : (
              <>
                <span className="text-2xl md:text-3xl font-serif font-bold text-primary leading-tight">Gyanmanjari</span>
                <span className="text-secondary font-medium tracking-wide text-xs md:text-sm">Career Institute</span>
              </>
            )}
          </button>
          
          {/* Desktop Nav */}
          <nav className="hidden lg:flex space-x-2 xl:space-x-4">
            {tabs.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button 
                  key={tab.id} 
                  onClick={() => setActiveTab(tab.id)} 
                  className={`relative px-4 py-2 rounded-full font-bold transition-all duration-300 flex items-center gap-2 cursor-pointer
                    ${isActive ? `${tab.activeBg} text-white shadow-md transform -translate-y-1` : `text-gray-600 hover:${tab.bg} hover:${tab.color} hover:-translate-y-1`}
                  `}
                >
                  <tab.icon className={`w-4 h-4 ${isActive ? 'text-white' : tab.color}`} />
                  <span className="text-sm font-sans tracking-wide whitespace-nowrap">{tab.name}</span>
                  {isActive && (
                    <motion.div 
                      layoutId="activeTabIndicator" 
                      className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-current" 
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Mobile Menu Button */}
          <button className="lg:hidden text-primary p-2 rounded-xl hover:bg-gray-100 transition-colors" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="lg:hidden absolute top-full left-0 w-full bg-white shadow-2xl py-6 px-6 flex flex-col space-y-3 border-t-4 border-dashed border-secondary/30 rounded-b-3xl"
        >
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button 
                key={tab.id} 
                onClick={() => {
                  setActiveTab(tab.id);
                  setIsOpen(false);
                }}
                className={`flex items-center gap-4 text-left font-bold text-lg px-6 py-3 rounded-2xl transition-all
                  ${isActive ? `${tab.activeBg} text-white shadow-md` : `text-gray-700 ${tab.bg} hover:shadow-sm`}
                `}
              >
                <div className={`p-2 rounded-xl ${isActive ? 'bg-white/20' : 'bg-white'}`}>
                  <tab.icon className={`w-6 h-6 ${isActive ? 'text-white' : tab.color}`} />
                </div>
                {tab.name}
              </button>
            );
          })}
        </motion.div>
      )}
    </header>
  );
}
