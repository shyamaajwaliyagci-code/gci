import { motion } from 'motion/react';
import { Shield, Sparkles, Image as ImageIcon, HeartHandshake } from 'lucide-react';

export default function HomeExtra() {
  const stats = [
    { label: "Happy Children", value: "500+" },
    { label: "Expert Educators", value: "40+" },
    { label: "Years of Excellence", value: "10+" },
    { label: "Creative Spaces", value: "15+" }
  ];

  return (
    <>
      <section className="py-24 bg-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-5xl font-serif font-bold text-primary mb-6">Why Parents & Kids Love GCI</h2>
              <p className="text-gray-600 text-lg leading-relaxed mb-8">
                We believe that every child is unique and deserves a space where they can truly belong, experiment, and grow at their own pace.
              </p>
              
              <div className="space-y-6">
                {[
                  { icon: Shield, title: "Safe & Secure Campus", color: "text-blue-500", bg: "bg-blue-50" },
                  { icon: Sparkles, title: "Creative & Play-Based Curriculum", color: "text-yellow-500", bg: "bg-yellow-50" },
                  { icon: HeartHandshake, title: "Warm & Experienced Teachers", color: "text-pink-500", bg: "bg-pink-50" }
                ].map((item, idx) => (
                  <div key={idx} className="flex items-start">
                    <div className={`w-12 h-12 ${item.bg} ${item.color} rounded-2xl flex items-center justify-center shrink-0 mr-4 mt-1`}>
                      <item.icon className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-gray-900 mb-1">{item.title}</h4>
                      <p className="text-gray-600 text-sm">We provide an environment where children feel completely at home, encouraging them to take their first independent steps.</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="grid grid-cols-2 gap-4">
                <img 
                  src="/home-1.png" 
                  alt="Kids playing" 
                  className="rounded-3xl object-cover h-64 w-full shadow-lg bg-gray-100" 
                  onError={(e) => { e.currentTarget.src = "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&q=80&w=600"; }}
                />
                <img 
                  src="/home-2.jpg" 
                  alt="Kids crafting" 
                  className="rounded-3xl object-cover h-64 w-full shadow-lg mt-8 bg-gray-100" 
                  onError={(e) => { e.currentTarget.src = "https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?auto=format&fit=crop&q=80&w=600"; }}
                />
              </div>
              
              {/* Floating element */}
              <div className="absolute -left-12 top-1/2 p-6 bg-white rounded-3xl shadow-xl border border-gray-100 hidden md:block animate-bounce" style={{ animationDuration: '3s' }}>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-2xl">🌟</div>
                  <div>
                    <p className="text-sm font-bold text-gray-900">Rated Excellent</p>
                    <p className="text-xs text-gray-500">By 500+ Parents</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-primary text-white border-y-8 border-secondary border-dashed">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-4">
            {stats.map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl md:text-5xl font-black mb-2 text-secondary-light">{stat.value}</div>
                <div className="text-sm md:text-base font-bold text-primary-100 tracking-wider uppercase">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
