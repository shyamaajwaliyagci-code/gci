import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { School, UserCircle, Heart } from 'lucide-react';

export default function Partner() {
  const [activeForm, setActiveForm] = useState<'school' | 'academic' | 'parent'>('school');

  return (
    <div className="bg-gray-50 pt-20">
      <section className="py-20 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="text-4xl md:text-5xl font-serif font-bold text-primary mb-6">Partner with GCI</h1>
            <p className="text-xl text-gray-600 leading-relaxed mb-10">
              Together, We Can Transform Education. Whether you are a school leader seeking transformation, an academician passionate about excellence, or a parent committed to your child's growth.
            </p>

            <div className="flex flex-col sm:flex-row justify-center gap-4 max-w-3xl mx-auto">
              <button 
                onClick={() => setActiveForm('school')}
                className={`py-4 px-6 rounded-2xl font-bold flex items-center justify-center transition-all flex-1 ${activeForm === 'school' ? 'bg-primary text-white shadow-xl' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
              >
                <School className="w-5 h-5 mr-2" /> For Schools
              </button>
              <button 
                onClick={() => setActiveForm('academic')}
                className={`py-4 px-6 rounded-2xl font-bold flex items-center justify-center transition-all flex-1 ${activeForm === 'academic' ? 'bg-secondary text-white shadow-xl' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
              >
                <UserCircle className="w-5 h-5 mr-2" /> For Academicians
              </button>
              <button 
                onClick={() => setActiveForm('parent')}
                className={`py-4 px-6 rounded-2xl font-bold flex items-center justify-center transition-all flex-1 ${activeForm === 'parent' ? 'bg-blue-600 text-white shadow-xl' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
              >
                <Heart className="w-5 h-5 mr-2" /> For Parents
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatePresence mode="wait">
            {activeForm === 'school' && (
              <motion.div
                key="school"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-white p-8 md:p-12 rounded-[2rem] shadow-xl border border-gray-100"
              >
                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold text-gray-900 font-serif mb-2">Proposal Request Form</h2>
                  <p className="text-gray-600 text-sm">Partner with GCI to Transform Your School</p>
                </div>
                
                <form className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">School Name</label>
                      <input type="text" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring focus:ring-primary/20 bg-gray-50 outline-none transition-all" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Contact Person</label>
                      <input type="text" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring focus:ring-primary/20 bg-gray-50 outline-none transition-all" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Mobile Number</label>
                      <input type="tel" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring focus:ring-primary/20 bg-gray-50 outline-none transition-all" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Email Address</label>
                      <input type="email" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring focus:ring-primary/20 bg-gray-50 outline-none transition-all" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Current Challenges</label>
                    <textarea rows={4} className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring focus:ring-primary/20 bg-gray-50 outline-none transition-all resize-none"></textarea>
                  </div>
                  <button type="button" className="w-full bg-primary hover:bg-primary/90 text-white font-bold text-lg py-4 rounded-xl transition-colors shadow-lg">
                    Request a Proposal
                  </button>
                </form>
              </motion.div>
            )}

            {activeForm === 'academic' && (
              <motion.div
                key="academic"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-white p-8 md:p-12 rounded-[2rem] shadow-xl border border-gray-100"
              >
                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold text-gray-900 font-serif mb-2">Associate with Us (For Academicians)</h2>
                  <p className="text-gray-600 text-sm">Join the GCI Network of Educational Experts</p>
                </div>
                
                <form className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Full Name</label>
                      <input type="text" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-secondary focus:ring focus:ring-secondary/20 bg-gray-50 outline-none transition-all" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Email Address</label>
                      <input type="email" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-secondary focus:ring focus:ring-secondary/20 bg-gray-50 outline-none transition-all" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Current Designation</label>
                      <input type="text" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-secondary focus:ring focus:ring-secondary/20 bg-gray-50 outline-none transition-all" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Years of Experience</label>
                      <input type="number" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-secondary focus:ring focus:ring-secondary/20 bg-gray-50 outline-none transition-all" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Areas of Expertise</label>
                    <textarea rows={3} placeholder="E.g. Early Childhood Education, Curriculum Development" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-secondary focus:ring focus:ring-secondary/20 bg-gray-50 outline-none transition-all resize-none"></textarea>
                  </div>
                  <button type="button" className="w-full bg-secondary hover:bg-secondary-light text-white font-bold text-lg py-4 rounded-xl transition-colors shadow-lg">
                    Join the GCI Network
                  </button>
                </form>
              </motion.div>
            )}

            {activeForm === 'parent' && (
              <motion.div
                key="parent"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-white p-8 md:p-12 rounded-[2rem] shadow-xl border border-gray-100"
              >
                <div className="text-center mb-8">
                  <h2 className="text-2xl font-bold text-gray-900 font-serif mb-2">Associate with Us (For Parents)</h2>
                  <p className="text-gray-600 text-sm">Become a Parent Partner with GCI</p>
                </div>
                
                <form className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Parent Name</label>
                      <input type="text" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring focus:ring-blue-500/20 bg-gray-50 outline-none transition-all" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Child's Name & Grade</label>
                      <input type="text" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring focus:ring-blue-500/20 bg-gray-50 outline-none transition-all" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Mobile Number</label>
                      <input type="tel" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring focus:ring-blue-500/20 bg-gray-50 outline-none transition-all" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Email Address</label>
                      <input type="email" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring focus:ring-blue-500/20 bg-gray-50 outline-none transition-all" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">How Would You Like to Contribute?</label>
                    <textarea rows={3} placeholder="E.g. Parenting Workshops, Volunteer" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring focus:ring-blue-500/20 bg-gray-50 outline-none transition-all resize-none"></textarea>
                  </div>
                  <button type="button" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold text-lg py-4 rounded-xl transition-colors shadow-lg">
                    Become a Parent Partner
                  </button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>
    </div>
  );
}
