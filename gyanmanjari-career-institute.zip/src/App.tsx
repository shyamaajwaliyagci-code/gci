/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import HomeDetails from './components/HomeDetails';
import HomePrograms from './components/HomePrograms';
import HomeExtra from './components/HomeExtra';
import About from './components/About';
import VisionMission from './components/VisionMission';
import Philosophy from './components/Philosophy';
import CoreValues from './components/CoreValues';
import Leadership from './components/Leadership';
import Services from './components/Services';
import SuccessStories from './components/SuccessStories';
import KnowledgeCorner from './components/KnowledgeCorner';
import Partner from './components/Partner';
import Footer from './components/Footer';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');

  return (
    <div className="min-h-screen flex flex-col font-sans selection:bg-secondary selection:text-white">
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-grow">
        {activeTab === 'home' && (
          <div className="bg-white">
            <Hero setActiveTab={setActiveTab} />
            <HomeDetails />
            <HomePrograms />
            <HomeExtra />
          </div>
        )}

        
        {activeTab === 'about' && (
          <div className="pt-20">
            <About />
            <VisionMission />
            <Philosophy />
            <CoreValues />
            <Leadership />
          </div>
        )}

        {activeTab === 'services' && (
          <Services />
        )}

        {activeTab === 'success' && (
          <SuccessStories />
        )}

        {activeTab === 'knowledge' && (
          <KnowledgeCorner />
        )}

        {activeTab === 'partner' && (
          <Partner />
        )}
      </main>
      <Footer />
    </div>
  );
}
